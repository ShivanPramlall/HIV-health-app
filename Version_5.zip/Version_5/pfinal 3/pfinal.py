from ast import Str
from email.base64mime import header_length
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import re
from datetime import datetime
from xml.etree.ElementTree import tostring
from transitions import Machine


class MutationDetection:
    states = ['initial', 'mutation_found', 'no_mutation_found']
    
    def __init__(self, reference_sequence, patient_sequence):
        self.reference_sequence = reference_sequence
        self.patient_sequence = patient_sequence
        self.mutations = []
        self.state = "initial"

        self.machine = Machine(model=self, states=MutationDetection.states, initial='initial')
        self.machine.add_transition(trigger='detect_mutations', source='initial', dest='mutation_found', conditions=['mutations_exist'])
        self.machine.add_transition(trigger='detect_mutations', source='initial', dest='no_mutation_found')
    
    def mutations_exist(self):
        if bool(self.mutations):
            self.state = 'mutation_found'
        else:
            self.state = 'no_mutation_found'
            
        return bool(self.mutations)

    def detect_mutations(self):
        # Ensure sequences are of the same length
        if len(self.reference_sequence) != len(self.patient_sequence):
            return self.mutations

        for i in range(len(self.reference_sequence)):
            if self.reference_sequence[i] != self.patient_sequence[i]:
                mutation_info = f"Position {i + 1}: {self.reference_sequence[i]} -> {self.patient_sequence[i]}"
                self.mutations.append(mutation_info)

        return self.mutations

class ReportGeneration:
    states = ['initial', 'report_generated']
    mutations = []
    
    def __init__(self, mutations, reference_sequence , patient_sequence):
        self.mutations = mutations
        self.reference_sequence = reference_sequence
        self.patient_sequence = patient_sequence
        self.report = ""
        self.state = "initial"

        self.machine = Machine(model=self, states=ReportGeneration.states, initial='initial')
        self.machine.add_transition(trigger='generate_report', source='initial', dest='report_generated', conditions=['mutations_exist'])

    def mutations_exist(self):
        if bool(self.mutations):
            self.state = 'report_generated'
        else:
            self.state = "initial"
            
        return bool(self.mutations)
    
    def generate_report(self):
        
        # Report Generation
        report = ""
        if self.mutations:
            report += "\n\n---------------------------------------------------------------------\n"
            report += "Initial Sequence:\n"
            report += self.reference_sequence + "\n\n"
            report += "Latest Sequence:\n"
            report += self.patient_sequence + "\n\n"
            report += "Mutations found:\n"

            for mutation in self.mutations:
                report += f"{mutation}\n"

            report += "\nSummary:\n"
            report += f"Total mutations detected: {len(self.mutations)}\n"
        else:
            report += "\n\n---------------------------------------------------------------------\n"
            report += "Reference Sequence:\n"
            report += self.reference_sequence + "\n\n"
            report += "Patient Sequence:\n"
            report += self.patient_sequence + "\n\n"
            report += "No mutations found.\n"

        return report
    
selected_patient = None  # Store the selected patient's ID   

# UI3
"""
NB: The code provided for HIV detection is not invalid, 
but it is overly simplistic and should not be used for actual HIV detection.
The provided code is meant for educational purposes and serves as a 
basic illustration of how a finite state machine (FSM) could be used to 
identify a specific DNA sequence ("GAG," "GTA,", "TACGCT" or "GTAG") in a string of 
genetic data. However, it does not accurately represent the complexity of HIV detection.
Real-world HIV detection involves a multifaceted and highly specific analysis 
of genetic markers, mutations, and other genetic characteristics of the virus. 
Such detection requires advanced laboratory techniques, specialized equipment, 
and deep knowledge of HIV genetics. 
"""

# Detects HIV given a biological sequence
class HIVDetectionFSM:
    def __init__(self):
        self.state = "START"

    def transition(self, base):
        if self.state == "START":
            if base == "G":
                self.state = "G_FOUND"
            if base == "T":
                self.state = "T_FOUND"
        elif self.state == "G_FOUND":
            if base == "A":
                self.state = "GA_FOUND"
            elif base == "T":
                self.state = "GT_FOUND"
            else:
                self.state = "START"
        elif self.state == "T_FOUND":
            if base == "A":
                self.state = "TA_FOUND"
            else:
                self.state = "START"
        elif self.state == "TA_FOUND":
            if base == "C":
                self.state = "TAC_FOUND"
            else:
                self.state = "START"
        elif self.state == "TAC_FOUND":
            if base == "G":
                self.state = "TACG_FOUND"
            else:
                self.state = "START"
        elif self.state == "TACG_FOUND":
            if base == "C":
                self.state = "TACGC_FOUND"
            else:
                self.state = "START"
        elif self.state == "TACGC_FOUND":
            if base == "T":
                self.state = "TACGCT_FOUND"
                return "HIV DETECTED"  # HIV detected when "TACGCT" is found
            else:
                self.state = "START"
        elif self.state == "GA_FOUND":
            if base == "G":
                self.state = "GAG_FOUND"
                return "HIV DETECTED"  # HIV detected when "GAG" is found
            elif base == "A":
                self.state = "GA_FOUND"
            else:
                self.state = "START"
        elif self.state == "GT_FOUND":
            if base == "A":
                self.state = "GTA_FOUND"
                return "HIV DETECTED"  # HIV detected when "GTA" is found
            elif base == "G":
                self.state = "GAG_FOUND"
                return "HIV DETECTED"  # HIV detected when "GAG" is found
            else:
                self.state = "START"
        elif self.state == "GTA_FOUND":
            if base == "G":
                self.state = "GTAG_FOUND"
                return "HIV DETECTED"  # HIV detected when "GTAG" is found
            elif base == "T":
                self.state = "GT_FOUND"
            else:
                self.state = "START"
        # End of the FSM
        return None  # No HIV detected yet

# Initialise the FSM and start the FSM to detect HIV
def analyze_genetic_data(sequence):
    fsm = HIVDetectionFSM()
    for base in sequence:
        result = fsm.transition(base)
        if result == "HIV DETECTED":
            return "HIV detected in the sequence."
    return "No HIV detected in the sequence."

# Predicts the patients health status using cd4 and viral load               
def predict_health_status(patient_data): # Using recommended function from below
    cd4_count = int(patient_data[10])
    viral_load = int(patient_data[11])
    
    if (cd4_count < 200):
        if (viral_load > 100000):
            status = "High Severity (Critical)"
        elif (viral_load > 1000):
            status = "Moderate Severity (Intermediate)"
        else:
            status = "Low Severity (Stable)"
    elif (cd4_count < 350):
        if (viral_load > 1000):
            status = "Moderate Severity (Intermediate)"
        else:
            status = "Low Severity (Stable)"
    else:
        status = "No Severity"
    return status

# Recommended action based on health status
def generate_health_assessment(patient_data):
    health_status = predict_health_status(patient_data)
    
    if (health_status == "High Severity (Critical)"):
        action = "Recommend immediate medical attention."
    elif (health_status == "Moderate Severity (Intermediate)"):
        action = "Recommend follow-up with healthcare provider."
    elif (health_status == "Low Severity (Stable)"):
        action = "Recommend continue monitoring CD4 count and viral load."
    else:
        action = "Recommend maintaining treatment and healthy lifestyle."
    return action

# Mutation Report
def generate_health_report(patient_data):
    display = "\n---------------------------------------------------------------------"
    display += "\nMutation detection report:"
    initial_sequence = patient_data[12]     # Inital Biological sequence
    latest_sequence = patient_data[13]       # Latest Biological sequence

    # Create a MutationDetection instance and detect mutations
    mutation_detection = MutationDetection(initial_sequence, latest_sequence)
    mutation_detection.detect_mutations()
    mutation_detection.mutations_exist()

    # Test the state of the Mutation Detection FSM
    if mutation_detection.state == 'mutation_found':
        display += "\nMutations found:"
        for mutation in mutation_detection.mutations:
            display += "\n" + mutation
    else:
        display += "\nNo mutations found.\n"

    # Create a ReportGeneration instance and generate a report
    report_generation = ReportGeneration(mutation_detection.mutations, initial_sequence, latest_sequence)
    report_generation.mutations_exist()

    # Test the state of the Report Generation FSM
    if report_generation.state == 'report_generated':
        display += report_generation.generate_report()
    else:
        display += "No mutations to generate a report.\n"
        
    return display
  
# Display necessary information
def display_health_status(patient_data):
    health_window = tk.Toplevel()
    health_window.title("Health Status")
    health_window.geometry("600x700")
    initial_sequence = patient_data[12]
    latest_sequence = patient_data[13]

    # Labels and Text Widgets to display patient's health information
    patient_id_label = tk.Label(health_window, text=f"Patient ID: {patient_data[0]}")
    patient_id_label.pack()
    
    patient_health_text = tk.Text(health_window, width=70, height=40)
    patient_health_text.pack()

    health_info = f"Full Name:{patient_data[1]}{patient_data[2]}\n"
    health_info += f"Date of Birth:{patient_data[3]}\n"
    health_info += f"Age: {patient_data[4]}\n"
    health_info += f"Gender:{patient_data[5]}\n"
    
    if (isinstance(initial_sequence, str) and bool(re.match(r'^[A-Z]+$', initial_sequence)) 
        and isinstance(latest_sequence, str) and bool(re.match(r'^[A-Z]+$', latest_sequence))):
        health_info += generate_health_report(patient_data) 
        health_info += "\n---------------------------------------------------------------------"
    
    if (isinstance(initial_sequence, str) and bool(re.match(r'^[A-Z]+$', initial_sequence))):
        health_info += f"\nHIV detection in initial biological sequence: \n{analyze_genetic_data(initial_sequence)}\n"
       
    if (isinstance(latest_sequence, str) and bool(re.match(r'^[A-Z]+$', latest_sequence))):
        health_info += f"\nHIV detection in latest biological sequence: \n{analyze_genetic_data(latest_sequence)}\n"
        
    health_info += f"\nPredicted Health Status: \n{predict_health_status(patient_data)}\n"
    health_info += f"\nRecommended Action: \n{generate_health_assessment(patient_data)}\n"

    # Add more health information as needed
    patient_health_text.insert(tk.END, health_info)
    patient_health_text.config(state=tk.DISABLED)

    # Button to close the window
    close_button = tk.Button(health_window, text="Close", command=health_window.destroy)
    close_button.pack()
# UI3 END
    
def login():
    username_get = username_entry.get()
    password_get = password_entry.get()

    with open("login.txt", "r") as file:
        for line in file:
            username, password = line.strip().split(":")
            if username_get == username and password_get == password:
                open_screen2()
                return

    messagebox.showerror('Login Failed')

def open_screen2():
    root.withdraw()

    next_screen = tk.Tk()
    next_screen.title("Home Page")
    next_screen.geometry("800x600")

    def show_patients():
        next_screen.withdraw()
        app = tk.Tk()
        app.title("Patient Information")
        columns = ("ID", "Name", "Surname", "DOB", "Age", "Gender", "Phone number", "Stage", "Transition Probabilities",
                   "Treatment Status", "CD4 Count", "Viral Load", "Initial Sequence", "Latest Sequence")
        patient_tree = ttk.Treeview(app, columns=columns, show="headings")

        for col in columns:
            patient_tree.heading(col, text=col)
        for col in columns:
            patient_tree.column(col, width=98)

        patient_tree.pack(pady=10)

        def add_data():
            try:
                with open("patient.txt", "r") as file:
                    patient_tree.delete(*patient_tree.get_children())
                    for line in file:
                        data = line.strip().split(",")
                        patient_tree.insert("", tk.END, values=data)
            except FileNotFoundError:
                print("File not found")

        add_data()

        def update_patient():
            selected_item = patient_tree.selection()
            if selected_item:
                current_values = patient_tree.item(selected_item)['values']
                edit_window = tk.Toplevel(app)
                edit_window.title("Edit Patient Information")

                entry_vars = []
                for i, col in enumerate(columns):
                    tk.Label(edit_window, text=col).grid(row=i, column=0, padx=5, pady=5)
                    var = tk.StringVar(value=current_values[i])
                    entry = tk.Entry(edit_window, textvariable=var)
                    entry.grid(row=i, column=1, padx=5, pady=5)
                    entry_vars.append(var)

                    def save_changes():
                        updated_values = [var.get() for var in entry_vars]
                        patient_tree.item(selected_item, values=updated_values)

                        try:
                            with open("patient.txt", "r") as file:
                                lines = file.readlines()
                            with open("patient.txt", "w") as file:
                                for line in lines:
                                    if line.strip().split(",") == current_values:
                                        file.write(",".join(updated_values) + "\n")
                                    else:
                                        file.write(line)
                            messagebox.showinfo("Success", "Patient information updated successfully!")
                        except FileNotFoundError:
                            print("File not found")

                        edit_window.destroy()

                    save_button = tk.Button(edit_window, text="Save Changes", command=save_changes)
                    save_button.grid(row=len(columns), columnspan=2, pady=10)

                else:
                    print("No patient selected for update")

        def delete_patient():                                   # Function to delete patient
            selected_item = patient_tree.selection()
            if selected_item:
                deleted_values = patient_tree.item(selected_item)['values']
                patient_tree.delete(selected_item)

                try:
                    with open("patient.txt", "r") as file:
                        lines = file.readlines()
                    with open("patient.txt", "w") as file:
                        for line in lines:
                            if line.strip().split(",") != deleted_values:
                                file.write(line)
                    messagebox.showinfo("Success", "Patient information deleted successfully!")
                except FileNotFoundError:
                    print("File not found")
                else:
                    print("No patient selected for delete")

        def exit_application():                             # Function to exit
            app.destroy()

        def go_to_home():                                   # Function to go back
            app.withdraw()
            next_screen.deiconify()
       
        def search_patient():                              # Function to search for a patient
            search_id = search_entry.get()
            found = False
            for item in patient_tree.get_children():
                if patient_tree.item(item, 'values')[0] == search_id:
                    patient_tree.selection_set(item)
                    found = True
                    break
            if not found:
                print(f"Patient with ID {search_id} not found.")
                
        def select_patient(event):
            global selected_patient
            selected_item = patient_tree.selection()  # Get the selected item
            if selected_item:
                selected_patient = selected_item[0]  # Store the selected item
                
        def print_selected_values():
            if selected_patient:
                # Get the values of the selected patient
                patient_values = patient_tree.item(selected_patient, "values")
                # for i in patient_values:
                #    print(i + " ")
       
                reference_sequence = patient_values[-2]     # Inital Biological sequence
                patient_sequence = patient_values[-1]       # Latest Biological sequence
        
                # Create a MutationDetection instance and detect mutations
                mutation_detection = MutationDetection(reference_sequence, patient_sequence)
                mutation_detection.detect_mutations()
                mutation_detection.mutations_exist()

                # Test the state of the Mutation Detection FSM
                if mutation_detection.state == 'mutation_found':
                    print("Mutations found:")
                    for mutation in mutation_detection.mutations:
                        print(mutation)
                else:
                    print("No mutations found.")


                # Create a ReportGeneration instance and generate a report
                report_generation = ReportGeneration(mutation_detection.mutations, reference_sequence, patient_sequence)
                report_generation.mutations_exist()

                # Test the state of the Report Generation FSM
                if report_generation.state == 'report_generated':
                    print("\nMutation detection report:")
                    print(report_generation.generate_report())
                else:
                    print("No mutations to generate a report.")


        # Function to recommend HIV/AIDS treatment based on CD4 count and viral load
        def recommend_treatment():
            selected_item = patient_tree.selection()
            if selected_item:
                current_values = patient_tree.item(selected_item)['values']
                cd4_count = int(current_values[10])
                viral_load = int(current_values[11])
        
                if cd4_count < 200:
                     if viral_load > 100000:
                        treatment_recommendation = "High Severity: Recommend starting Antiretroviral Therapy (ART) immediately."
                     elif viral_load > 1000:
                        treatment_recommendation = "Moderate Severity: Recommend starting ART."
                     else:
                       treatment_recommendation = "Low Severity: Continue monitoring CD4 count and viral load."
                elif cd4_count < 350:
                     if viral_load > 1000:
                        treatment_recommendation = "Moderate Severity: Recommend starting ART."
                     else:
                         treatment_recommendation = "Low Severity: Continue monitoring CD4 count and viral load."
                else:
                     treatment_recommendation = "No Severity: Continue monitoring CD4 count and viral load."

               # Display the recommendation in a messagebox
                messagebox.showinfo("Treatment Recommendation", treatment_recommendation)
            else:
                 messagebox.showerror("Error", "No patient selected for treatment recommendation")
        
        # UI3
        def display_health():
            selected_item = patient_tree.selection()
            if selected_item:
                current_values = patient_tree.item(selected_item)['values']
                display_health_status(current_values)   # Function to get UI3
            else:
                messagebox.showerror("Error", "No patient selected for Health Status.")
        # UI3 END

        search_label = tk.Label(app, text="Enter the Patient ID:", font=('Arial', '10', 'bold'))
        search_label.pack(side=tk.LEFT, pady=5)
        search_entry = tk.Entry(app, font=('Arial', '12'))
        search_entry.pack(side=tk.LEFT, pady=5, padx=10)

        button_style = {'width': 15, 'height': 2, 'bg': 'red', 'fg': 'white', 'font': ('Arial', '10', 'bold')}

        search_button = tk.Button(app, text="Search", command=search_patient, bg="#FF0000", fg="#fff",
                                  font=('Arial', '10', 'bold'))
        search_button.pack(side=tk.LEFT, pady=5, padx=10)

        update_button = tk.Button(app, text="Update", command=update_patient, **button_style)
        treatment_button = tk.Button(app, text="Treatment", command=recommend_treatment, **button_style)
        delete_button = tk.Button(app, text="Delete", command=delete_patient, **button_style)
        back_button = tk.Button(app, text="Go to Home Page", command=go_to_home, **button_style)
        exit_button = tk.Button(app, text="Exit", command=exit_application, **button_style)
        print_mutations_button = tk.Button(app, text="Print Mutations", command=print_selected_values,**button_style) 
        exit_button.pack(side=tk.RIGHT, pady=5, padx=10)
        back_button.pack(side=tk.RIGHT, pady=5, padx=10)
        delete_button.pack(side=tk.RIGHT, pady=5, padx=10)
        treatment_button.pack(side=tk.RIGHT, pady=5, padx=10)
        update_button.pack(side=tk.RIGHT, pady=5, padx=10)
        print_mutations_button.pack(side=tk.RIGHT, pady=5, padx=10)
        
        # UI3
        # Button to display health status, added to UI2
        display_health_button = tk.Button(app, text="Health Status", command=display_health, **button_style)
        display_health_button.pack(side=tk.RIGHT, pady=5, padx=10)
        # UI3 END
        
        # Bind a function to click events on the Treeview to select a patient
        patient_tree.bind("<ButtonRelease-1>", select_patient)

        app.mainloop()

    def add_patients():
        next_screen.withdraw()

        def write_to_file(data):
            try:
                with open("patient.txt", "a") as file:
                    if file.tell() != 0:
                        file.write("\n")
                        file.write(data)
            except Exception as e:
                messagebox.showerror("Error", f"Error writing to file: {str(e)}")

        def go_to_home():
            root.withdraw()
            next_screen.deiconify()

        def submit():
            def is_valid_id(id_str):
                return re.match(r'^\d{13}$', id_str) is not None

            def is_valid_name(name_str):
                return re.match(r'^[A-Za-z\s]+$', name_str)

            def is_valid_surname(surname_str):
                return re.match(r'^[A-Za-z\s]+$', surname_str)

            def is_valid_dob(dob_str):
                try:
                    dob_date = datetime.strptime(dob_str, '%d/%m/%Y')
                    return dob_date.year == (datetime.now().year - int(age))
                except ValueError:
                    return False

            def is_valid_age(age_str):
                return re.match(r'^\d{1,3}$', age_str) and 1 <= int(age_str) <= 150

            def is_valid_gender(gender_str):
                return gender_str in ["Male", "Female"]

            def is_valid_phone(phone_str):
                return re.match(r'^\d{10}$', phone_str)

            def is_valid_stage(stage_str):
                return stage_str in ["1", "2", "3"]

            def is_valid_transition_prob(transition_str):
                return re.match(r'^\d{1,3}$', transition_str) and 0 <= int(transition_str) <= 100

            def is_valid_treatment_status(status_str):
                return status_str in ["Yes", "No"]

            def is_valid_cd4_count(cd4_str):
                return re.match(r'^\d{1,4}$', cd4_str) and 0 <= int(cd4_str) <= 2000

            def is_valid_viral_load(viral_load_str):
                return re.match(r'^\d+$', viral_load_str)

            user_id = entry_id.get()
            name = entry_name.get()
            surname = entry_surname.get()
            dob = entry_dob.get()
            age = entry_age.get()
            gender = entry_gender.get()
            phone_number = entry_phone.get()
            stage = entry_stage.get()
            transition_probabilities = entry_trans_prob.get()
            treatment_status = entry_treatment.get()
            cd4_count = entry_cd4.get()
            viral_load = entry_viral_load.get()
            initial_sequence = entry_initial_sequence.get()
            latest_sequence = entry_latest_sequence.get()

            if not is_valid_id(user_id):
                messagebox.showerror("Error", "Invalid ID")
                return

            if not is_valid_name(name):
                messagebox.showerror("Error", "Invalid Name")
                return

            if not is_valid_surname(surname):
                messagebox.showerror("Error", "Invalid Surname")
                return

            if not is_valid_dob(dob):
                messagebox.showerror("Error", "Invalid Date of Birth or Age")
                return

            if not is_valid_age(age):
                messagebox.showerror("Error", "Invalid Age")
                return

            if not is_valid_gender(gender):
                messagebox.showerror("Error", "Invalid Gender")
                return

            if not is_valid_phone(phone_number):
                messagebox.showerror("Error", "Invalid Phone Number")
                return

            if not is_valid_stage(stage):
                messagebox.showerror("Error", "Invalid Stage")
                return

            if not is_valid_transition_prob(transition_probabilities):
                messagebox.showerror("Error", "Invalid Transition Probabilities")
                return

            if not is_valid_treatment_status(treatment_status):
                messagebox.showerror("Error", "Invalid Treatment Status")
                return

            if not is_valid_cd4_count(cd4_count):
                messagebox.showerror("Error", "Invalid CD4 Count")
                return

            if not is_valid_viral_load(viral_load):
                messagebox.showerror("Error", "Invalid Viral Load")
                return

            
            data_to_write = f"{user_id}, {name}, {surname}, {dob}, {age}, {gender}, {phone_number}, {stage}, {transition_probabilities}, {treatment_status}, {cd4_count}, {viral_load}, {initial_sequence}, {latest_sequence}"
            write_to_file(data_to_write)
            messagebox.showinfo("Success", "Patient information added successfully!")
            root.withdraw()
            next_screen.deiconify()

        root = tk.Tk()
        root.title("Patient Information Form")
        root.geometry("900x900")

        font = ("Helvetica", 10)

        labels = ["ID:", "Name:", "Surname:", "Date of Birth (dd/mm/yyyy):", "Age:", "Gender(Male or Female):",
                  "Phone Number (10 digits):", "Stage (1=Acute, 2=Chronic, 3=Acquired immunodeficiency syndrome):",
                  "Transition Probabilities (0-100):", "Treatment Status (Yes or No):", "CD4 Count (0-2000):",
                  "Viral Load (numbers only):","Initial Biological Sequence:",
                  "Latest Biological Sequence:"]
        entry_widgets = []

        for label_text in labels:
            label = tk.Label(root, text=label_text, font=font)
            label.pack()

            entry = tk.Entry(root, font=font)
            entry.pack(fill=tk.X, padx=10, pady=5)
            entry_widgets.append(entry)

        entry_id = entry_widgets[0]
        entry_name = entry_widgets[1]
        entry_dob = entry_widgets[3]
        entry_surname = entry_widgets[2]
        entry_age = entry_widgets[4]
        entry_gender = entry_widgets[5]
        entry_phone = entry_widgets[6]
        entry_stage = entry_widgets[7]
        entry_trans_prob = entry_widgets[8]
        entry_treatment = entry_widgets[9]
        entry_cd4 = entry_widgets[10]
        entry_viral_load = entry_widgets[11]
        entry_initial_sequence = entry_widgets[12]
        entry_latest_sequence = entry_widgets[13]

        submit_button = tk.Button(root, text="Submit Patient Details", command=submit, font=font)
        submit_button.pack(side=tk.LEFT)
     
        home_button = tk.Button(root, text="Go to Home Page", command=go_to_home, font=font)
        home_button.pack(side=tk.RIGHT)

        root.mainloop()

    show_patients_button = tk.Button(next_screen, text='Show Existing Patients', command=show_patients)
    show_patients_button.pack()

    add_patient_button = tk.Button(next_screen, text='Add New Patient', command=add_patients)
    add_patient_button.pack()

root = tk.Tk()
root.title("Login Page")
root.geometry("800x600")

username_l = tk.Label(root, text='Username')
username_l.pack()

username_entry = tk.Entry(root)
username_entry.pack()

password_l = tk.Label(root, text="Password")
password_l.pack()

password_entry = tk.Entry(root, show="*")
password_entry.pack()

login_button = tk.Button(root, text="Login", command=login)
login_button.pack()

root.mainloop()